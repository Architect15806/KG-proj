//package minslab.kbase.neo4j.dao;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class EntityNodeDaoTest {
//    @Autowired
//    private EntityNodeDao entityNodeDao;
//
//    @Test
//    void testOperation(){
//        System.out.println(entityNodeDao.findAll());
//        // add node
//        EntityNode entityNode = new EntityNode();
//        entityNode.setId(6);
//        entityNode.setName("jason");
//        entityNode.setAge(30);
//        System.out.println(entityNodeDao.save(entityNode));
//    }
//
//}
