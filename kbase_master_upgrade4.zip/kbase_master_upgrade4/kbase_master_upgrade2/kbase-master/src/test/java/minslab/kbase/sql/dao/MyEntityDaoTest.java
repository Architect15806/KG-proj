//package minslab.kbase.mysql.dao;
//
//import minslab.kbase.mysql.domain.MyEntity;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class MyEntityDaoTest {
//    @Autowired
//    private MyEntityDao myEntityDao;
//
//    @Test
//    void testOperation(){
//        // find
////        System.out.println(myEntityDao.findAll());
//        // findById()返回的是optional类的对象，optional.isPresent()检查是不是Null，optional.get()得到对象
//        System.out.println(myEntityDao.findById(3));
//        // save
////        MyEntity myEntity = new MyEntity();
////        myEntity.setId(4);
////        myEntity.setName("peter");
////        myEntity.setAge(36);
////        System.out.println(myEntityDao.save(myEntity));
//        // delete
////        myEntityDao.deleteById(2);
//        // get 获取对象的代理，不要用这种方法
////        System.out.println(myEntityDao.getById(4));
//
//    }
//
//}
