package minslab.kbase.vo;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class TestVO {

    int id;

    String name;

    int age;
}
