package minslab.kbase.sql.domain;


import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name = "my_entity")
@Data
public class MyEntity {
    @Id
    private Integer id;
    private String name;
    private Integer age;
}
