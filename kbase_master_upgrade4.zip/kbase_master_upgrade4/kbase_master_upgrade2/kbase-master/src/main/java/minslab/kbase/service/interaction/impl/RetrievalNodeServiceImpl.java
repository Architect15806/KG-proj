package minslab.kbase.service.interaction.impl;

import minslab.kbase.sql.domain.neo4j.dao.CommonNodeDao;
import minslab.kbase.sql.domain.neo4j.dao.NodeRelationshipDao;
import minslab.kbase.sql.domain.neo4j.domain.CommonNode;
import minslab.kbase.service.interaction.RetrievalNodeService;
import org.neo4j.driver.internal.value.RelationshipValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class RetrievalNodeServiceImpl implements RetrievalNodeService {

    @Autowired
    CommonNodeDao commonNodeDao;

    @Autowired
    NodeRelationshipDao nodeRelationshipDao;

    @Override
    public CommonNode entityRetrievalByName(String name){
        if(commonNodeDao.getCommonNodeByName(name).size()==0) return null;
        return commonNodeDao.getCommonNodeByName(name).get(0);
    }

    @Override
    public List<CommonNode> getAllRelatedNodesByName(String name){
        if(commonNodeDao.getCommonNodesByName(name).size()==0) return null;
        return commonNodeDao.getCommonNodesByName(name);
    }

    @Override
    public List<String> getRelationshipBetweenTwoNodes(String name1, String name2){
        List<String> result = new ArrayList<>();
        for(Object obj: nodeRelationshipDao.getRelationBetweenTwoNodes(name1, name2)){
            RelationshipValue temp = (RelationshipValue)obj;
            result.add(String.valueOf(temp.get("type")));
        }
        return result;
    }

    @Override
    public void deleteNodeByName(String name){
        commonNodeDao.deleteEntityByName(name);
    }

    @Override
    public List<String> getAllNodeNames(){
        return commonNodeDao.getAllEntityNames();
    }

    @Override
    public void deleteRelationshipByName(String name1, String name2, String type){
        commonNodeDao.deleteRelationshipByName(name1, name2, type);
    }


    @Override
    public void deleteEntityAndRelationByName(String name){
        commonNodeDao.deleteEntityAndRelationByName(name);
    }

}
