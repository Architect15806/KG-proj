package minslab.kbase.vo;

public class NodeVO {

}
