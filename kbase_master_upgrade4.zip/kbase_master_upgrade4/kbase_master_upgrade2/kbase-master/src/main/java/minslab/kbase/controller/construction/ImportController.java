package minslab.kbase.controller.construction;

import minslab.kbase.common.ANode;
import minslab.kbase.common.Result;
import minslab.kbase.service.RedisServer.RedisServer;
import minslab.kbase.service.construction.ImportNodeService;
import minslab.kbase.service.interaction.RetrievalNodeService;
import minslab.kbase.sql.domain.neo4j.domain.CommonNode;
import minslab.kbase.sql.domain.neo4j.domain.NodeRelationship;
import minslab.kbase.sql.domain.redis.domain.RedisRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@CrossOrigin
@RestController
public class ImportController {

    @Autowired
    private ImportNodeService importNodeService;

    @Autowired
    private RedisServer redisServer;

    @Autowired
    private RetrievalNodeService retrievalNodeService;

    @PostMapping("/importCsv")
    public Result<Object> importCsv(@RequestParam("file") MultipartFile file, @RequestParam("relationStart") int relationStart, @RequestParam("characterStart") int characterStart) {

        System.out.println(file);
        System.out.println(relationStart);
        System.out.println(characterStart);
        if (file.isEmpty()) {
            return Result.failed("File is empty!");
        }
        try {
            List<RedisRecord> toAdd = importNodeService.importCsv(file,true, relationStart, characterStart);
            redisServer.RedisImport(toAdd);
        } catch (IOException e) {
            e.printStackTrace();
            return Result.failed("IO error!");
        }

        return Result.success();
    }

    @CrossOrigin
    @RequestMapping("/ReadCsv")
    public Result<List<HashMap<String, String>>> ReadCsv(@RequestParam("file") MultipartFile file, @RequestParam("relationStart") int relationStart, @RequestParam("characterStart") int characterStart) throws IOException {
        if (file.isEmpty()) {
            return Result.failed("File is empty!");
        }
        return Result.success(importNodeService.ReadCsv(file, true, relationStart, characterStart));
    }

    @CrossOrigin
    @RequestMapping("/ReadJson")
    public Result<List<HashMap<String, String>>> ReadJson(@RequestParam("file") MultipartFile file) throws IOException {
        if (file.isEmpty()) {
            return Result.failed("File is empty!");
        }
        return Result.success(importNodeService.ReadJson(file));
    }

    @PostMapping("/SaveJson")
    public Result<String> SaveJson(@RequestBody List<HashMap<String, String>> toSave) {
        if(toSave==null) return Result.failed("Null!");
        importNodeService.SaveJson(toSave);
        return Result.success("Success!");
    }
    // TODO:
    // 1. 无论是单独的 entity, 还是在关系中出现的 entity，后写入的会覆盖先写入的属性；
    // 2. 如何单独添加关系
    @PostMapping("/importJson")
    public Result<Object> importJson(@RequestParam("file") MultipartFile file) {

        if (file.isEmpty()) {
            return Result.failed("File is empty!");
        }

        try {
            importNodeService.importJson(file, true);
        } catch (IOException e) {
            e.printStackTrace();
            return Result.failed("IO error!");
        }

        return Result.success();
    }

    @PostMapping("/deleteAll")
    public Result<String> deleteAll() {
        importNodeService.deleteAll();
        redisServer.deleteAll();
        return Result.success();
    }

    @PostMapping("/addNode")
    public Result<ANode> addNode(@RequestParam("name")String name, @RequestParam("type")String type, @RequestParam("location")String location, @RequestParam("description")String description, @RequestBody HashMap<String, String> otherCharacter) {
        System.out.println("*********************************");
        System.out.println(otherCharacter);
        CommonNode temp = retrievalNodeService.entityRetrievalByName(name);
        if (type == null){
            type = temp.getType();
        }
        if (location == null){
            location = temp.getLocation();
        }
        if (description == null){
            description = temp.getDescription();
        }
        importNodeService.incrementalSave(new CommonNode(name, type, location, description));
        if (otherCharacter!=null){
            if (redisServer.exists(name)){
                RedisRecord r = redisServer.getRecord(name);
                otherCharacter.putAll(r.getCharacterList());
                redisServer.putHash(name, otherCharacter);
            }
            else {
                redisServer.putHash(name, otherCharacter);
            }
        }
        return Result.success(new ANode(name, type, location, description, new RedisRecord(name, otherCharacter)));
    }

    @PostMapping("/addCharacter")
    public Result<String> addCharacter(@RequestParam("name") String name, @RequestParam("key") String key, @RequestParam("value") String value){
        if (retrievalNodeService.entityRetrievalByName(name)!=null){
            if(redisServer.exists(name)){
                RedisRecord tempRecord = redisServer.getRecord(name);
                tempRecord.getCharacterList().put(key, value);
                redisServer.putHash(name, tempRecord.getCharacterList());
            }
            else {
                HashMap<String, String> tempHash = new HashMap<>();
                tempHash.put(key, value);
                redisServer.putHash(name, tempHash);
            }
        }
        else {
            return Result.failed("The node does not exist.");
        }
        return Result.success("Success!");
    }

    @GetMapping("/addRelationship")
    public Result<String> addNode(@RequestParam("name1")String name1, @RequestParam("name2")String name2, @RequestParam("type")String type) {
        if(retrievalNodeService.getAllRelatedNodesByName(name1).size()==0||retrievalNodeService.getAllRelatedNodesByName(name2).size()==0){
            return Result.failed("Can not add the relationship because one node does not exist!");
        }
        if (!retrievalNodeService.getRelationshipBetweenTwoNodes(name1, name2).contains(type)){
            try {
                importNodeService.addRelationship(name1, name2, type);
            }catch (Exception e){
                return Result.failed("Error!");
            }
        }
        return Result.success("Adding finished!");
    }

    @PostMapping("/addANodeAndRelationships")
    public Result<ANode> addANodeAndRelationships(@RequestParam("name")String name, @RequestParam("type")String type, @RequestParam("location")String location, @RequestParam("description")String description, @RequestBody HashMap<String, String> otherInfo) {
        System.out.println("*********************************");
        System.out.println(name);
        System.out.println(type);
        System.out.println(location);
        System.out.println(description);
        System.out.println(otherInfo);
        CommonNode temp = retrievalNodeService.entityRetrievalByName(name);
        if (type == null) {
            type = temp.getType();
        }
        if (location == null) {
            location = temp.getLocation();
        }
        if (description == null) {
            description = temp.getDescription();
        }
        if (otherInfo.get("node_names") != null) {
            String[] relatedNames = otherInfo.get("node_names").split(",");
            String[] relatedTypes = otherInfo.get("types").split(",");
            List<NodeRelationship> rl = new ArrayList<>();
            if(temp!=null){
                rl = temp.getRelationshipList();
            }
            for (int i = 0; i < relatedNames.length; i++) {
                System.out.println(retrievalNodeService.entityRetrievalByName(relatedNames[i]));
                if (retrievalNodeService.entityRetrievalByName(relatedNames[i])!=null){
                    rl.add(new NodeRelationship(relatedTypes[i], retrievalNodeService.entityRetrievalByName(relatedNames[i])));
                }
                else {
                    rl.add(new NodeRelationship(relatedTypes[i], new CommonNode(relatedNames[i])));
                }

            }
            importNodeService.incrementalSave(new CommonNode(name, type, location, description, rl));
        }
        if (otherInfo.get("characters") != null) {
            String[] tempInfo = otherInfo.get("characters").split(",");
            HashMap<String, String> otherCharacter = new HashMap<>();
            for (String s : tempInfo) {
                otherCharacter.put(s.split(":")[0], s.split(":")[1]);
            }
            if (redisServer.exists(name)) {
                RedisRecord r = redisServer.getRecord(name);
                otherCharacter.putAll(r.getCharacterList());
                redisServer.putHash(name, otherCharacter);
            } else {
                redisServer.putHash(name, otherCharacter);
            }
            return Result.success(new ANode(name, type, location, description, new RedisRecord(name, otherCharacter)));
        }
        return Result.success(new ANode(name, type, location, description, new RedisRecord(name, null)));
    }
    @PostMapping("/updateANodeAndRelationships")
    public Result<ANode> updateANodeAndRelationships(@RequestParam("name")String name, @RequestParam(value = "type",required = false)String type, @RequestParam(value = "location",required = false)String location, @RequestParam(value = "description",required = false)String description, @RequestBody HashMap<String, String> otherInfo) {
        System.out.println(name);
        System.out.println(type);
        System.out.println(location);
        System.out.println(description);
        System.out.println(otherInfo);
        CommonNode temp = retrievalNodeService.entityRetrievalByName(name);
        if (type == null) {
            type = temp.getType();
        }
        if (location == null) {
            location = temp.getLocation();
        }
        if (description == null) {
            description = temp.getDescription();
        }

        redisServer.del(name);
        HashMap<String, String> otherCharacter = new HashMap<>();
        if (otherInfo.get("characters") != null && otherInfo.get("characters").length()!=0) {
            String[] tempInfo = otherInfo.get("characters").split(",");
            for (String s : tempInfo) {
                otherCharacter.put(s.split(":")[0], s.split(":")[1]);
            }
            RedisRecord r = redisServer.getRecord(name);
            if(r!=null){
                HashMap<String, String> t = r.getCharacterList();
                t.putAll(otherCharacter);
                otherCharacter=t;
            }
        }


        if (retrievalNodeService.getAllRelatedNodesByName(name)==null){
            retrievalNodeService.deleteNodeByName(name);
        }
        else {
            retrievalNodeService.deleteEntityAndRelationByName(name);
        }

        if (otherInfo.get("node_names") != null && otherInfo.get("node_names").length()!=0) {
            String[] relatedNames = otherInfo.get("node_names").split(",");
            String[] relatedTypes = otherInfo.get("types").split(",");
            List<NodeRelationship> rl = new ArrayList<>();
            if(temp!=null){
                rl = temp.getRelationshipList();
            }
            for (int i = 0; i < relatedNames.length; i++) {
                if (retrievalNodeService.entityRetrievalByName(relatedNames[i])!=null){
                    rl.add(new NodeRelationship(relatedTypes[i], retrievalNodeService.entityRetrievalByName(relatedNames[i])));
                }
                else {
                    rl.add(new NodeRelationship(relatedTypes[i], new CommonNode(relatedNames[i])));
                }
            }
            importNodeService.incrementalSave(new CommonNode(name, type, location, description, rl));
        }
        else {
            importNodeService.incrementalSave(temp);
        }


        RedisRecord r = redisServer.getRecord(name);
        if(r!=null){
            redisServer.putHash(name, otherCharacter);
            return Result.success(new ANode(name, type, location, description, new RedisRecord(name, otherCharacter)));
        }
        return Result.success(new ANode(name, type, location, description, new RedisRecord(name, null)));
    }

    @RequestMapping("/unStructureFileImport")
    public Result<String> unStructureFileImport(@RequestParam("text")MultipartFile text){
        System.out.println("text");
        System.out.println(text);
        if (text.isEmpty()) {
            return Result.failed("File is empty!");
        }
        try {
            String result = importNodeService.unStructureFileImport(text);
            return Result.success(result);
        } catch (IOException e) {
            e.printStackTrace();
            return Result.failed("IO error!");
        }
    }


}
