//package minslab.kbase.redis.domain;
//
//import lombok.AllArgsConstructor;
//import lombok.Getter;
//
//@AllArgsConstructor
//@Getter
//public class Task {
//
//    Long id;
//
//    String topic;
//
//    Object data;
//
//    Object result;
//}
