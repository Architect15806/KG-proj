package minslab.kbase.service.construction;

import minslab.kbase.sql.domain.neo4j.domain.CommonNode;
import minslab.kbase.sql.domain.redis.domain.RedisRecord;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;


public interface ImportNodeService {

    public List<RedisRecord> importCsv(MultipartFile file, boolean withHeader, int relationStart, int characterStart) throws IOException;

    public void importJson(MultipartFile file, boolean withHeader) throws IOException;

    public void deleteAll();

    // TODO: 包装成事务
    CommonNode incrementalSave(CommonNode entity);

    List<HashMap<String, String>> ReadJson(MultipartFile file) throws IOException;

    void SaveJson(List<HashMap<String, String>> toSave);

    List<HashMap<String, String>> ReadCsv(MultipartFile file, boolean withHeader, int relationStart, int characterStart) throws IOException;

    void addRelationship(String name1, String name2, String type);

    String unStructureFileImport(MultipartFile file) throws IOException;
}
