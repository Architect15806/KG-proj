package minslab.kbase.service.construction.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import minslab.kbase.common.POJOUtils;
import minslab.kbase.sql.domain.neo4j.dao.CommonNodeDao;
import minslab.kbase.sql.domain.neo4j.dao.NodeRelationshipDao;
import minslab.kbase.sql.domain.neo4j.domain.*;
import minslab.kbase.service.construction.ImportNodeService;
import minslab.kbase.sql.domain.redis.domain.RedisRecord;
import org.neo4j.driver.internal.value.RelationshipValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.*;

@Service
public class ImportNodeServiceImpl implements ImportNodeService {
    @Autowired
    private CommonNodeDao commonNodeDao;

    @Autowired
    private NodeRelationshipDao nodeRelationshipDao;


    private CommonNode arrayToCommonNode(String[] array) {
        return new CommonNode(
                array[0],
                array[1],
                array[2],
                array[3]
        );
    }


    @Override
    public List<RedisRecord> importCsv(MultipartFile file, boolean withHeader, int relationStart, int characterStart) throws IOException {

        InputStream is = file.getInputStream();

        BufferedReader reader = new BufferedReader(new InputStreamReader(is));

        List<CommonNode> records = new ArrayList<>();
        List<String> all_records = new ArrayList<>();
        List<String> type_names = new ArrayList<>();
        String line = reader.readLine();
        List<RedisRecord> toReturn = new ArrayList<>();
        if (withHeader) {
            type_names = Arrays.asList(line.split(","));
            line = reader.readLine();
        }
        else{
            for(int i = 0; i < line.split(",").length; i++){
                type_names.add("column"+ i);
            }
        }
        ;
        while (line != null) {
            all_records.add(line);
            String[] values = line.split(",");
            records.add(arrayToCommonNode(values));
            line = reader.readLine();
        }
        for (CommonNode cm : records) {
            incrementalSave(cm);
        }

        for (int i = 0; i < characterStart-relationStart; i++) {
            for (String l : all_records) {
                records.clear();
                String[] ls = l.split(",");
                CommonNode temp_node = commonNodeDao.getCommonNodeByName(ls[0]).get(0);

                String[] nodesList = ls[relationStart+i].split(" ");
                for (String s : nodesList) {
                    if (commonNodeDao.getCommonNodeByName(s).size() == 0) {
                        CommonNode temp = new CommonNode(s);
                        temp_node.addRelationship(new NodeRelationship(type_names.get(relationStart+i), temp));
                        incrementalSave(temp_node);
                        records.add(temp);
                    } else {
                        List<String> result = new ArrayList<>();
                        for(Object obj: nodeRelationshipDao.getRelationBetweenTwoNodes(temp_node.getName(), s)){
                            RelationshipValue temp = (RelationshipValue)obj;
                            result.add(temp.get("type").toString().substring(1, 3));
                        }
                        if(!result.contains(type_names.get(relationStart+i))){
                            temp_node.addRelationship(new NodeRelationship(type_names.get(relationStart+i), commonNodeDao.getCommonNodeByName(s).get(0)));
                        }
                        incrementalSave(temp_node);
                    }
                }
                commonNodeDao.saveAll(records);
            }
        }

        for (int i = characterStart; i < type_names.size(); i++) {
            for (String l : all_records) {
                String[] ls = l.split(",");
                String RecordName = ls[0];
                String type = type_names.get(i);
                String values = ls[i];
                HashMap<String, String> m = new HashMap<>();
                m.put(type, values);
                toReturn.add(new RedisRecord(RecordName, m));
            }
        }
        return toReturn;
    }
    @Override
    public void importJson(MultipartFile file, boolean withHeader) throws IOException {

        InputStream is = file.getInputStream();

        BufferedReader reader = new BufferedReader(new InputStreamReader(is));

        ObjectMapper mapper = new ObjectMapper();
        List items = mapper.readValue(reader, List.class);

        for (Object o: items) {
            HashMap<String, Object> item = (HashMap<String, Object>) o;
            CommonNode entity = new CommonNode();
            HashMap<String, String> other = new HashMap<>();
            HashMap<String, HashMap<String, String>> otherR = new HashMap<>();

            for (String key: item.keySet()) {
                if (key.equals("name")) {
                    if (item.get(key)==null){
                        continue;
                    }
                    entity.setName((String)item.get(key));
                } else if (key.equals("type")) {
                    if (item.get(key)==null){
                        continue;
                    }
                    entity.setType((String)item.get(key));
                } else if (key.equals("location")) {
                    if (item.get(key)==null){
                        continue;
                    }
                    entity.setLocation((String)item.get(key));
                } else if (key.equals("description")) {
                    if (item.get(key)==null){
                        continue;
                    }
                    entity.setDescription((String)item.get(key));
                }
                else if(key.split("[*]").length>1){
                    String t = key.split("[*]")[0];
                    List<NodeRelationship> tempRelation = entity.getRelationshipList();
                    String[] targetList = item.get(key).toString().split(",");
                    for(String s: targetList){
                        if(commonNodeDao.getCommonNodeByName(s).size()!=0){
                            List<String> result = new ArrayList<>();
                            for(Object obj: nodeRelationshipDao.getRelationBetweenTwoNodes(entity.getName(), s)){
                                RelationshipValue temp = (RelationshipValue)obj;
                                result.add(temp.get("type").toString().substring(1, 3));
                            }

                            if(!result.contains(t)){
                                tempRelation.add(new NodeRelationship(t, commonNodeDao.getCommonNodeByName(s).get(0)));
                            }
                        }
                        else {
                            incrementalSave(new CommonNode(s));
                            tempRelation.add(new NodeRelationship(t, commonNodeDao.getCommonNodeByName(s).get(0)));
                        }
                    }
                    entity.setRelationshipList(tempRelation);
                }
                else {
                    other.put(key, (String)item.get(key));
                }
            }
            if (other.size()!=0){
                otherR.put(entity.getName(), other);
            }
            incrementalSave(entity);
        }
    }

    @Override
    public void deleteAll() {
        commonNodeDao.deleteEntities();
    }

    public CommonNode queryAndUpdatePersonEntity(CommonNode entity) {
        CommonNode entityToSave = entity;
        List<CommonNode> results = commonNodeDao.getCommonNodeByName(entity.getName());
        if (results.size() == 1) {
            POJOUtils.copyPropertiesExceptNull(entityToSave, results.get(0));
            entityToSave = results.get(0);
        }
        return entityToSave;
    }

    // TODO: 包装成事务
    @Override
    public CommonNode incrementalSave(CommonNode entity) {

        // 本方法执行增量存储策略：
        // 1. 查询数据库是否已经存在同 ID 的实体 persist;
        // 2. 若存在，将待存储的 entity 的非 null 字段赋值给 persist, 存储更新后的 persist;
        // 3. 否则，直接存储 entity;
        CommonNode entityToSave = queryAndUpdatePersonEntity(entity);

        // 对
//        if (entityToSave.getPerson() != null) {
//            for (PersonRelatedTo p: entityToSave.getPerson()) {
//                p.setPerson(queryAndUpdatePersonEntity(p.getPerson()));
//            }
//        }

        return commonNodeDao.save(entityToSave);
    }

    @Override
    public List<HashMap<String, String>> ReadCsv(MultipartFile file, boolean withHeader, int relationStart, int characterStart) throws IOException {

        InputStream is = file.getInputStream();

        BufferedReader reader = new BufferedReader(new InputStreamReader(is));

        List<String> type_names = new ArrayList<>();
        List<HashMap<String, String>> toReturn = new ArrayList<>();
        String line = reader.readLine();
        if (withHeader) {
            type_names = Arrays.asList(line.split(","));
            line = reader.readLine();
        }
        else{
            for(int i = 0; i < line.split(",").length; i++){
                type_names.add("column"+ i);
            }
        }
        int j = 0;
        while (line != null) {
            String[] temp = line.split(",");
            HashMap<String, String> temp_result = new HashMap<>();
            for (int i=0; i<temp.length; i++){
                if (i<characterStart && i>=relationStart){
                    temp_result.put(type_names.get(i)+"*关系", temp[i]);
                }

                temp_result.put(type_names.get(i), temp[i]);
            }
            temp_result.put("id", Integer.toString(j));
            j++;
            toReturn.add(temp_result);
            line = reader.readLine();
        }
        return toReturn;

    }

    @Override
    public List<HashMap<String, String>> ReadJson(MultipartFile file) throws IOException {

        InputStream is = file.getInputStream();

        BufferedReader reader = new BufferedReader(new InputStreamReader(is));

        ObjectMapper mapper = new ObjectMapper();
        List items = mapper.readValue(reader, List.class);
        List<HashMap<String, String>> toReturn = new ArrayList<>();
        int i = 0;
        for (Object o : items) {
            HashMap<String, String> temp_result = new HashMap<>();
            HashMap<String, Object> item = (HashMap<String, Object>) o;

            for (String key : item.keySet()) {
                temp_result.put(key, item.get(key).toString());
            }
            temp_result.put("id", Integer.toString(i));
            toReturn.add(temp_result);
            i++;
        }
        return toReturn;
    }

    @Override
    public void SaveJson(List<HashMap<String, String>> toSave){
        for (HashMap<String, String> item: toSave) {
            CommonNode entity = new CommonNode();
            HashMap<String, String> other = new HashMap<>();

            for (String key: item.keySet()) {
                if(key.equals("id")){
                    continue;
                }
                if (key.equals("名称")) {
                    if (item.get(key)==null){
                        continue;
                    }
                    entity.setName(item.get(key));
                } else if (key.equals("类型")) {
                    if (item.get(key)==null){
                        continue;
                    }
                    entity.setType(item.get(key));
                } else if (key.equals("省市")) {
                    if (item.get(key)==null){
                        continue;
                    }
                    entity.setLocation(item.get(key));
                } else if (key.equals("描述")) {
                    if (item.get(key)==null){
                        continue;
                    }
                    entity.setDescription(item.get(key));
                }
                else if(key.split("[*]").length>1){
                    String t = key.split("[*]")[0];
                    List<NodeRelationship> tempRelation = entity.getRelationshipList();
                    String[] targetList = item.get(key).toString().split(",");
                    for(String s: targetList){
                        if(commonNodeDao.getCommonNodeByName(s).size()!=0){
                            List<String> result = new ArrayList<>();
                            for(Object obj: nodeRelationshipDao.getRelationBetweenTwoNodes(entity.getName(), s)){
                                RelationshipValue temp = (RelationshipValue)obj;
                                result.add(temp.get("type").toString().substring(1, 3));
                            }

                            if(!result.contains(t)){
                                tempRelation.add(new NodeRelationship(t, commonNodeDao.getCommonNodeByName(s).get(0)));
                            }
                        }
                        else {
                            incrementalSave(new CommonNode(s));
                            tempRelation.add(new NodeRelationship(t, commonNodeDao.getCommonNodeByName(s).get(0)));
                        }
                    }
                    entity.setRelationshipList(tempRelation);
                }
                else {
                    other.put(key, item.get(key));
                }
            }
            incrementalSave(entity);
        }
    }




    @Override
    public void addRelationship(String name1, String name2, String type){
        CommonNode node1 = commonNodeDao.getCommonNodeByName(name1).get(0);
        CommonNode node2 = commonNodeDao.getCommonNodeByName(name2).get(0);
        node1.addRelationship(new NodeRelationship(type, node2));
        incrementalSave(node1);
    }

    @Override
    public String unStructureFileImport(MultipartFile file) throws IOException {
        String path = "E:/DaChuang/OurModel/demo1.0ase-master2/unstructFile/result.csv";
        InputStream is = file.getInputStream();
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        String line = reader.readLine();
        List<String> result = new ArrayList<>();
        while (line != null) {
            try {
                String[] args = new String[]{"D:\\Anaconda\\envs\\pytorch\\python.exe", "E:\\Tencent Files\\testFile.py", path, line};
                Process proc = Runtime.getRuntime().exec(args);// 执行py文件

                BufferedReader in = new BufferedReader(new InputStreamReader(proc.getInputStream(), "GBK"));
                String resultLine = null;
                while ((resultLine = in.readLine()) != null) {
                    result.add(resultLine);
                }
                in.close();
                proc.waitFor();
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            }
            line = reader.readLine();
        }
        System.out.println(result);
        return result.toString();
    }
}
