package minslab.kbase.sql.domain.redis.domain;

import lombok.*;
import org.springframework.data.neo4j.core.schema.GeneratedValue;
import org.springframework.data.neo4j.core.schema.Id;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RedisRecord implements Serializable {
    private String NodeName;
    private HashMap<String, String> CharacterList;

}
