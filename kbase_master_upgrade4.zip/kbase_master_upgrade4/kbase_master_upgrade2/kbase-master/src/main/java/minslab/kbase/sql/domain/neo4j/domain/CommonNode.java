package minslab.kbase.sql.domain.neo4j.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.neo4j.core.schema.Id;
import org.springframework.data.neo4j.core.schema.Node;
import org.springframework.data.neo4j.core.schema.Relationship;

import java.util.ArrayList;
import java.util.List;

@Data
@Node(labels = "CommonNode")
@NoArgsConstructor
@AllArgsConstructor
public class CommonNode {
    @Id
    String name;
    String type;
    String location;
    String description;

    @Relationship(type = "Relation", direction = Relationship.Direction.OUTGOING)
    List<NodeRelationship> relationshipList = new ArrayList<>();

    public CommonNode(String name, String type, String location, String description) {
        this.name = name;
        this.type = type;
        this.location = location;
        this.description = description;
    }

    public CommonNode(String name) {
        this.name = name;
    }

    public void addRelationship(NodeRelationship toAddNodeRelationship){
        if (relationshipList == null) {
            relationshipList = new ArrayList<>();
        }
        relationshipList.add(toAddNodeRelationship);
    }
}
