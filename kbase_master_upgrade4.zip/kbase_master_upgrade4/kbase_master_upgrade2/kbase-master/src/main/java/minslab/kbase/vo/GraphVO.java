package minslab.kbase.vo;

import java.util.List;

public class GraphVO {

    List<NodeVO> nodes;

    List<LinkVO> links;
}
