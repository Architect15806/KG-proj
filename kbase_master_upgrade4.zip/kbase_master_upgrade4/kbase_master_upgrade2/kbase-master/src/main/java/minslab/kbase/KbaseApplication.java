package minslab.kbase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KbaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(KbaseApplication.class, args);
	}

}
