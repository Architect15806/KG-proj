package minslab.kbase.service.interaction;

import minslab.kbase.sql.domain.neo4j.domain.CommonNode;
import minslab.kbase.sql.domain.neo4j.domain.NodeRelationship;
import org.neo4j.driver.Record;
import org.neo4j.driver.types.Relationship;
import org.w3c.dom.Node;

import java.util.HashMap;
import java.util.List;

public interface RetrievalNodeService {
    CommonNode entityRetrievalByName(String name);

    List<CommonNode> getAllRelatedNodesByName(String name);

    List<String> getRelationshipBetweenTwoNodes(String name1, String name2);

    void deleteNodeByName(String name);

    List<String> getAllNodeNames();

    void deleteRelationshipByName(String name1, String name2, String type);

    void deleteEntityAndRelationByName(String name);
}
