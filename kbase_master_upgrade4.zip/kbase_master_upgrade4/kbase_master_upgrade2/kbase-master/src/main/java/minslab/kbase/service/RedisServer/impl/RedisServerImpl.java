package minslab.kbase.service.RedisServer.impl;

import com.alibaba.fastjson.JSON;
import minslab.kbase.service.RedisServer.RedisServer;
import minslab.kbase.sql.domain.redis.domain.RedisRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

@Service
public class RedisServerImpl implements RedisServer {
    @Autowired
    private StringRedisTemplate redisTemplate;

    public <T> void put(String key, T obj) {
        redisTemplate.opsForValue().set(key, JSON.toJSONString(obj));
    }

    public <T> void put(String key, T obj, int timeout) {
        put(key,obj,timeout, TimeUnit.MINUTES);
    }

    public <T> void put(String key, T obj, int timeout, TimeUnit unit) {
        redisTemplate.opsForValue().set(key, JSON.toJSONString(obj),timeout,unit);
    }

    public <T> T get(String key, Class<T> cls) {
        return JSON.parseObject(JSON.toJSONString(redisTemplate.opsForValue().get(key)), cls);
    }

    @Override
    public <E, T extends Collection<E>> T get(String key, Class<E> cls, Class<T> collectionCls) {
        return null;
    }

    /***
     public <E, T extends Collection<E>> T get(String key, Class<E> cls, Class<T> collectionCls) {
     return JSON.parseArray(JSON.toJSONString(redisTemplate.opsForValue().get(key)), cls, collectionCls);
     }**/

    public <T> T putIfAbsent(String key, Class<T> cls, Supplier<T> supplier) {
        T t=get(key,cls);
        if(null==t){
            t=supplier.get();
            if(null!=t)
                put(key,t);
        }
        return t;
    }

    public <T> T putIfAbsent(String key, Class<T> cls, Supplier<T> supplier, int timeout) {
        T t=get(key,cls);
        if(null==t){
            t=supplier.get();
            if(null!=t)
                put(key,t,timeout);
        }
        return t;
    }

    public <E, T extends Collection<E>> T putIfAbsent(String key, Class<E> cls, Class<T> collectionCls,
                                                      Supplier<T> supplier) {
        T t=get(key,cls,collectionCls);
        if(null==t || t.isEmpty()){
            t=supplier.get();
            if(null!=t && t.size()>0)
                put(key,t);
        }
        return t;
    }

    public boolean exists(String key) {
        return redisTemplate.hasKey(key);
    }

    public void del(String key) {
        redisTemplate.delete(key);
    }

    public boolean expire(String key, long timeout, TimeUnit unit) {
        return redisTemplate.expire(key, timeout, unit);
    }

    public boolean expire(String key, long timeout) {
        return redisTemplate.expire(key, timeout, TimeUnit.MINUTES);
    }

    public void put(String key, String value) {
        redisTemplate.opsForValue().set(key, value);
    }

    public void put(String key, String value, int timeout) {
        put(key,value,timeout,TimeUnit.MINUTES);
    }

    public void put(String key, String value, int timeout, TimeUnit unit) {
        redisTemplate.opsForValue().set(key, value, timeout, unit);
    }

    public String get(String key) {
        return (String) redisTemplate.opsForValue().get(key);
    }

    public void putHash(String key, Map<Object,Object> m) {
        redisTemplate.opsForHash().putAll(key, m);
    }
    public void putHash(String key, HashMap<String,String> m) {
        redisTemplate.opsForHash().putAll(key, m);
    }

    public Map<Object, Object> getHash(String key) {
        try{
            return redisTemplate.opsForHash().entries(key);
        }catch(Exception e){
            return null;
        }
    }
    public RedisRecord getRecord(String key){
        try{
            Map<Object, Object> map = redisTemplate.opsForHash().entries(key);
            HashMap<String, String> result = new HashMap<>();
            for (Map.Entry<Object, Object> entry : map.entrySet()) {
                String mapKey = entry.getKey().toString();
                String mapValue = entry.getValue().toString();
                result.put(mapKey, mapValue);
            }
            return new RedisRecord(key, result);
        }catch(Exception e){
            return null;
        }

    }
    @Override
    public void RedisImport(List<RedisRecord> toAdd){
        for (RedisRecord r: toAdd){
            if (!exists(r.getNodeName())){
                putHash(r.getNodeName(), r.getCharacterList());
            }
            else{
                RedisRecord temp = getRecord(r.getNodeName());
                for (HashMap.Entry<String, String> entry : r.getCharacterList().entrySet()){
                    temp.getCharacterList().put(entry.getKey(), entry.getValue());
                }
               putHash(temp.getNodeName(), temp.getCharacterList());
            }
        }
    }

    @Override
    public void deleteAll(){
        Set<String> keys = redisTemplate.keys("*");
        if (keys!=null){
            redisTemplate.delete(keys);
        }
    }
}