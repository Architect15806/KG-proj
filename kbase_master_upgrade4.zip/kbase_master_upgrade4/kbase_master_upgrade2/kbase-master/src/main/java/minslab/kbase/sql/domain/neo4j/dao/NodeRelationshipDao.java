package minslab.kbase.sql.domain.neo4j.dao;

import minslab.kbase.sql.domain.neo4j.domain.NodeRelationship;
import org.neo4j.driver.Record;
import org.neo4j.driver.types.Relationship;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.neo4j.repository.query.Query;

import java.util.List;
public interface NodeRelationshipDao extends Neo4jRepository<NodeRelationship, Long> {

    @Query("MATCH (a:CommonNode{name:$name1})-[r]-(b:CommonNode{name:$name2}) RETURN r")
    List<Object> getRelationBetweenTwoNodes(String name1, String name2);
}
