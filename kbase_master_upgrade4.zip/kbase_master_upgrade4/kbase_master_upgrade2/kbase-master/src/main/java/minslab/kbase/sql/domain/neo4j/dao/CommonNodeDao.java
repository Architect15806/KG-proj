package minslab.kbase.sql.domain.neo4j.dao;

import minslab.kbase.sql.domain.neo4j.domain.CommonNode;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.neo4j.repository.query.Query;

import java.util.List;

public interface CommonNodeDao extends Neo4jRepository<CommonNode, String> {

    // 仅查询该实体的属性
    @Query("MATCH (a:CommonNode) WHERE a.name=$name RETURN a")
    List<CommonNode> getCommonNodeByName(String name);

    // 查询与该实体有关联的实体的属性
    @Query("MATCH (a:CommonNode)-[r]-(b:CommonNode) WHERE a.name=$name RETURN b")
    List<CommonNode> getCommonNodesByName(String name);

    // 删除与PersonEntity相关的所有实体和关系
    @Query("MATCH (n:CommonNode)" +
            "OPTIONAL MATCH (n:CommonNode)-[r]-(m)" +
            "DELETE n,r,m")
    void deleteEntities();

    // TODO： 数据量增大时必须分页，否则服务容易卡死
    // 查询所有 PersonEntity 的 name 属性
    @Query("MATCH (n:CommonNode)" +
            "RETURN n.name")
    List<String> getAllEntityNames();


    // 删除与PersonEntity相关的所有实体和关系
    @Query("match(d:CommonNode{name:$name}) delete d")
    void deleteEntityByName(String name);

    // 删除指定关系
    @Query("MATCH (a:CommonNode{name:$name1})-[r]-(b:CommonNode{name:$name2}) DELETE r")
    String deleteRelationshipByName(String name1, String name2, String type);

    // 删除与PersonEntity相关的所有实体和关系
    @Query("match(d:CommonNode{name:$name})-[r]-(b:CommonNode) delete d, r")
    void deleteEntityAndRelationByName(String name);


}
