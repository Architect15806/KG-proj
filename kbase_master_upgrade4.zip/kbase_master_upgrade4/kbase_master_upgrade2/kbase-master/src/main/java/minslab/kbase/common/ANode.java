package minslab.kbase.common;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import minslab.kbase.sql.domain.redis.domain.RedisRecord;

import java.io.Serializable;
import java.util.HashMap;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ANode implements Serializable {
    String name;
    String type;
    String location;
    String description;

    RedisRecord redisRecord;

    @Override
    public String toString() {
        return "ANode{" +
                "name='" + name + '\'' +
                ", type='" + type + '\'' +
                ", location='" + location + '\'' +
                ", description='" + description + '\'' +
                ", redisRecord=" + redisRecord.getCharacterList() +
                '}';
    }

    public HashMap<String, String> toHashMapWithoutID() {
        HashMap<String, String> result = new HashMap<>();
        result.put("name", this.getName());
        result.put("type", this.getType());
        result.put("location", this.getLocation());
        result.put("description", this.getDescription());
        if(this.getRedisRecord()!=null){
            for(HashMap.Entry entry: this.getRedisRecord().getCharacterList().entrySet()){
                result.put((String) entry.getKey(), (String) entry.getValue());
            }
        }
        return result;
    }

    public HashMap<String, String> toHashMap(int id) {
        HashMap<String, String> result = new HashMap<>();
        result.put("id", Integer.toString(id));
        result.put("name", this.getName());
        result.put("type", this.getType());
        result.put("location", this.getLocation());
        result.put("description", this.getDescription());
        if(this.getRedisRecord()!=null){
            for(HashMap.Entry entry: this.getRedisRecord().getCharacterList().entrySet()){
                result.put((String) entry.getKey(), (String) entry.getValue());
            }
        }
        return result;

    }
}
