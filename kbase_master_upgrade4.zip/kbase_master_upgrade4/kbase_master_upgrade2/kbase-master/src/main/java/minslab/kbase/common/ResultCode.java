package minslab.kbase.common;

import lombok.Getter;

public enum ResultCode {

    SUCCESS(10000, "请求成功"),
    FAILED(10001, "操作失败"),
    NONE(99999, "无");

    @Getter
    private int code;

    @Getter
    private String msg;

    private ResultCode(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }


}
