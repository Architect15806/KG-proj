package minslab.kbase.controller;


import minslab.kbase.sql.domain.mysql.dao.NodeRecordDao;
import minslab.kbase.sql.domain.mysql.domain.NodeRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("user")
public class TestMysqlController {

    @Autowired
    private NodeRecordDao nodeRecordDao;

    @RequestMapping("/getAllUser")
    @ResponseBody
    public List<NodeRecord> findAll() {
        return nodeRecordDao.findAll();
    }

    @RequestMapping("/getByUserName")
    @ResponseBody
    public List<NodeRecord> getByUserName(@RequestParam("NodeName")String NodeName) {
        return nodeRecordDao.getByNodeName(NodeName);
    }

    @RequestMapping("/addRecord")
    @ResponseBody
    public void getByUserName(@RequestParam("NodeName")String NodeName, @RequestParam("c1")String c1, @RequestParam("c2")String c2) {
        nodeRecordDao.save(new NodeRecord(NodeName, c1, c2));
    }

    @RequestMapping("/deleteRecord")
    @ResponseBody
    public void deleteByUserName(@RequestParam("NodeName")String NodeName) {
        nodeRecordDao.deleteById(nodeRecordDao.getByNodeName(NodeName).get(0).getId());
    }

}