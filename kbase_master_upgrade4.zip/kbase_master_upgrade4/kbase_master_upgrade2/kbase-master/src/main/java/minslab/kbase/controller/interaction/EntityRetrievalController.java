package minslab.kbase.controller.interaction;

import minslab.kbase.common.ANode;
import minslab.kbase.common.Result;
import minslab.kbase.service.RedisServer.RedisServer;
import minslab.kbase.service.interaction.RetrievalNodeService;
import minslab.kbase.sql.domain.neo4j.domain.CommonNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

@CrossOrigin
@RestController
public class EntityRetrievalController {

    @Autowired
    RetrievalNodeService retrievalNodeService;

    @Autowired
    RedisServer redisServer;


    // TODO 方法测试
    @GetMapping("/searchNodeByName")
    public Result<ANode> searchEntity(@RequestParam("name") String name) {

        CommonNode entity = retrievalNodeService.entityRetrievalByName(name);
        if (entity == null) {
            return Result.failed(String.format("名称为<%s>的实体不存在！", name));
        }
        return Result.success(new ANode(entity.getName(), entity.getType(), entity.getLocation(), entity.getDescription(), redisServer.getRecord(name)));
    }

    @GetMapping("/searchAllRelatedNodes")
    public Result<List<CommonNode>> searchRelatedEntity(@RequestParam("name") String name){
        List<CommonNode> nodeList = retrievalNodeService.getAllRelatedNodesByName(name);
        if (nodeList == null) {
            return Result.failed(String.format("<%s>的实体无相关节点！", name));
        }
        return Result.success(nodeList);
    }

    @GetMapping("/searchRelationshipBetweenTwoNodes")
    public Result<List<String>> searchRelationshipBetweenTwoNodes(@RequestParam("name1") String name1, @RequestParam("name2") String name2) {
        try{
            List<String> result = retrievalNodeService.getRelationshipBetweenTwoNodes(name1, name2);
            if(result==null){
                return Result.failed("No relationship between the two nodes.");
            }
            else {
                return Result.success(result);
            }
        }catch (Exception e){
            return Result.failed("Search failed!");
        }
    }

    @PostMapping ("/deleteNodeByName")
    public Result<String> deleteNodeByName(@RequestParam("name") String name) {
        System.out.println(name);
        if(retrievalNodeService.getAllRelatedNodesByName(name)==null){
            System.out.println("11111111111111111");
            retrievalNodeService.deleteNodeByName(name);
        }
        else {
            System.out.println("222222222222222");
            retrievalNodeService.deleteEntityAndRelationByName(name);
        }

        redisServer.del(name);
        return Result.success("Delete success!");
    }

    @PostMapping("deleteThemAll")
    public Result<String> deleteThemAll(@RequestParam("nameList") String nameList){
        for(String s: nameList.split(",")){

            if(retrievalNodeService.getAllRelatedNodesByName(s)==null){
                retrievalNodeService.deleteNodeByName(s);
            }
            else {
                retrievalNodeService.deleteEntityAndRelationByName(s);
            }
            redisServer.del(s);
        }
        return Result.success("Success!");
    }


    @GetMapping("/getAllNodeNames")
    public Result<List<String>> getAllNodeNames() {
        try{
            List<String> result = retrievalNodeService.getAllNodeNames();
            return Result.success(result);
        }catch (Exception e){
            return Result.failed("Error!");
        }
    }

    @GetMapping("/deleteRelationship")
    public Result<String> deleteRelationship(@RequestParam("name1") String name1, @RequestParam("name2") String name2, @RequestParam("type") String type) {
        try{
            retrievalNodeService.deleteRelationshipByName(name1, name2, type);
            return Result.success("Delete success!");
        }catch (Exception e){
            return Result.failed("Error!");
        }
    }

    @GetMapping("/getNodeAndRelatedNodes")
    public Result<HashMap<String, List<HashMap<String, String>>>> getNodeAndRelatedNodes(@RequestParam("name") String name){
        int node_id_counter = 0;
        int type_id_counter = 0;
        HashMap<String, String> helper = new HashMap<>();
        CommonNode mainNode = retrievalNodeService.entityRetrievalByName(name);
        List<CommonNode> relatedNodeList = retrievalNodeService.getAllRelatedNodesByName(name);

        if (mainNode == null) return Result.failed(String.format("名称为<%s>的实体不存在！", name));

        if(relatedNodeList==null){
            ANode r =  new ANode(mainNode.getName(), mainNode.getType(), mainNode.getLocation(), mainNode.getDescription(), redisServer.getRecord(mainNode.getName()));
            HashMap<String, List<HashMap<String, String>>> result = new HashMap<>();
            List<HashMap<String, String>> s = new ArrayList<>();
            s.add(r.toHashMap(0));
            result.put("nodes", s);
            result.put("links", null);
            return Result.success(result);
        }

        HashSet<CommonNode> set = new HashSet<>(relatedNodeList);
        relatedNodeList.clear();
        relatedNodeList.addAll(set);


        List<ANode> relatedANodeList = new ArrayList<>();
        ANode mainANode = new ANode(mainNode.getName(), mainNode.getType(), mainNode.getLocation(), mainNode.getDescription(), redisServer.getRecord(mainNode.getName()));
        for (CommonNode rnl: relatedNodeList){
            relatedANodeList.add(new ANode(rnl.getName(), rnl.getType(), rnl.getLocation(), rnl.getDescription(), redisServer.getRecord(rnl.getName())));
        }
        List<HashMap<String, String>> relatedANodes = new ArrayList<>();
        List<HashMap<String, String>> relatedTypes = new ArrayList<>();

        if (!relatedNodeList.contains(mainNode)){
            relatedANodes.add(mainANode.toHashMap(node_id_counter));
            helper.put(mainANode.getName(), Integer.toString(node_id_counter));
            node_id_counter++;
        }
        for(ANode ad: relatedANodeList){
            if (!helper.containsKey(ad.getName())){
                relatedANodes.add(ad.toHashMap(node_id_counter));
                helper.put(ad.getName(), Integer.toString(node_id_counter));
                node_id_counter++;
            }
        }

        for(ANode ad: relatedANodeList){
            HashMap<String, String> temp = new HashMap<>();
            temp.put("id", Integer.toString(type_id_counter));
            temp.put("source", helper.get(mainANode.getName()));
            temp.put("target", helper.get(ad.getName()));
            temp.put("category", retrievalNodeService.getRelationshipBetweenTwoNodes(ad.getName(),mainNode.getName()).toString());
            relatedTypes.add(temp);
            type_id_counter++;
        }

        HashMap<String, List<HashMap<String, String>>> result = new HashMap<>();
        result.put("nodes", relatedANodes);
        result.put("links", relatedTypes);
        return Result.success(result);
    }

    @GetMapping("/getAllNodeAndRelationship")
    public Result<HashMap<String, List<HashMap<String, String>>>> getAllNodeAndRelatedNodes(){
        int node_id_counter = 0;
        int type_id_counter = 0;
        HashMap<String, String> helper = new HashMap<>();

        List<String> allNodeNames = retrievalNodeService.getAllNodeNames();
        List<HashMap<String, String>> allANodeList = new ArrayList<>();
        List<HashMap<String, String>> relatedTypes = new ArrayList<>();
        for(String n: allNodeNames){
            CommonNode tempNode = retrievalNodeService.entityRetrievalByName(n);
            if(!helper.containsKey(n)){
                allANodeList.add(new ANode(n, tempNode.getType(), tempNode.getLocation(), tempNode.getDescription(), redisServer.getRecord(n)).toHashMap(node_id_counter));
                helper.put(n, Integer.toString(node_id_counter));
                node_id_counter++;
            }
        }
        int len = allNodeNames.size();
        for(int i=0; i<len; i++){
            String name1 = allNodeNames.get(i);
            for(int j=i; j<len; j++){
                String name2 = allNodeNames.get(j);
                if(retrievalNodeService.getRelationshipBetweenTwoNodes(name1, name2).size()!=0){
                    HashMap<String, String> temp = new HashMap<>();
                    temp.put("id", Integer.toString(type_id_counter));
                    temp.put("source", helper.get(name1));
                    temp.put("target", helper.get(name2));
                    temp.put("category", retrievalNodeService.getRelationshipBetweenTwoNodes(name1, name2).toString());
                    type_id_counter++;
                    relatedTypes.add(temp);
                }
            }
        }
        HashMap<String, List<HashMap<String, String>>> result = new HashMap<>();
        result.put("nodes", allANodeList);
        result.put("links", relatedTypes);
        return Result.success(result);
    }
}
