package minslab.kbase.sql.domain.neo4j.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.data.neo4j.core.schema.GeneratedValue;
import org.springframework.data.neo4j.core.schema.Id;
import org.springframework.data.neo4j.core.schema.RelationshipProperties;
import org.springframework.data.neo4j.core.schema.TargetNode;

@RelationshipProperties
@AllArgsConstructor
@NoArgsConstructor
@Getter
public class NodeRelationship{

    @Id
    @GeneratedValue
    private Long id;

    private String type;

    @TargetNode
    private CommonNode target_node;

    public NodeRelationship(String ty, CommonNode target){
        this.target_node = target;
        this.type = ty;
    }

}