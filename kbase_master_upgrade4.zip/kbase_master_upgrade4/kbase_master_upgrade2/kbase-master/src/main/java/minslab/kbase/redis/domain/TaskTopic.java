//package minslab.kbase.redis.domain;
//
//import lombok.Getter;
//
//@Getter
//public enum TaskTopic {
//
//    TESTTASK(0L, "TESTTASK");
//
//    private Long id;
//
//    private String topic;
//
//    private TaskTopic(Long id, String topic) {
//        this.id = id;
//        this.topic = topic;
//    }
//}
