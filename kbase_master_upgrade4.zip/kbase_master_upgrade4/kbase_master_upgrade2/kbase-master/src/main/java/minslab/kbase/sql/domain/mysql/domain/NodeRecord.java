package minslab.kbase.sql.domain.mysql.domain;

import lombok.Getter;
import lombok.ToString;

import java.io.Serializable;

import javax.persistence.*;

@Entity
@Getter
@ToString
@Table(name = "noderecord")
public class NodeRecord implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nodename")
    private String nodeName;

    @Column(name = "c1")
    private String c1;

    @Column(name = "c2")
    private String c2;

    public NodeRecord(String nodeName, String c1, String c2){
        this.nodeName = nodeName;
        this.c1 = c1;
        this.c2 = c2;
    }

    public NodeRecord() {}
}