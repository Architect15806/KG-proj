package minslab.kbase.vo;

public class LinkVO {

}
